
CREATE DATABASE Mercadito;

CREATE TABLE TBL_Productos (
	prd_id int identity,
	prd_descripcion varchar(250),
	prd_precio decimal(10,0),
	prd_costo decimal(10,0),
	PRIMARY KEY(prd_id)
);

CREATE TABLE TBL_Bodegas (
	bdg_id int identity,
	bdg_descripcion varchar(150),
	PRIMARY KEY(bdg_id)
);

CREATE TABLE TBL_Bodegas_Detalle (
	bdgd_id int,
	bdg_id int,
	prd_id int,
	bdg_cantidad_producto int,
	bdg_ubicacion_producto varchar(250),
	PRIMARY KEY(bdgd_id),
	FOREIGN KEY (bdg_id) REFERENCES TBL_Bodegas(bdg_id)
);

CREATE TABLE TBL_Proveedores (
	prv_id int identity,
	prv_nombre varchar(150),
	prv_tipo_proveedor varchar(50),
	PRIMARY KEY(prv_id),
);

CREATE TABLE TBL_Clientes (
	clt_id int identity,
	clt_nombre varchar(250),
	clt_direccion varchar(250),
	clt_limite_credito int,
	PRIMARY KEY(clt_id),
);

CREATE TABLE TBL_Factura (
	fct_id int identity,
	clt_id int,
	fct_total decimal(10,0),
	fct_fecha datetime
	PRIMARY KEY(fct_id),
	FOREIGN KEY (clt_id) REFERENCES TBL_Clientes(clt_id)
);

CREATE TABLE TBL_Factura_Detalle (
	fctd_id int identity,
	fct_id int,
	fctd_cantidad int,
	PRIMARY KEY(fctd_id),
	FOREIGN KEY (fct_id) REFERENCES TBL_Factura(fct_id)
);

CREATE TABLE TBL_Credito_Clientes (
	crd_id int identity,
	fct_id int,
	PRIMARY KEY(crd_id),
	FOREIGN KEY (fct_id) REFERENCES TBL_Factura(fct_id)
);

CREATE TABLE TBL_Gasto_Casa (
	gcs_id int identity,
	gcs_total decimal(10,0),
	PRIMARY KEY(gcs_id)
);

CREATE TABLE TBL_Gasto_Casa_Detalle (
	gcsd_id int identity,
	gcs_id int,
	prd_id int,
	gcs_cantidad int,
	PRIMARY KEY(gcsd_id),
	FOREIGN KEY (gcs_id) REFERENCES TBL_Gasto_Casa(gcs_id),
	FOREIGN KEY (prd_id) REFERENCES TBL_Productos(prd_id)
);


INSERT INTO TBL_Productos (
	prd_descripcion,
	prd_precio,
	prd_costo 
) values (
			'Manzana',
			'50',
			'35'
			),
			(
			'Pera',
			'48',
			'30'
			),
			(
			'Banano',
			'15',
			'6'
			),
			(
			'Uva',
			'65',
			'33'
			),
			(
			'culantro fino',
			'2',
			'0.5'
			),
			(
			'culantro ancho',
			'2',
			'0.5'
			),
			(
			'papa',
			'26',
			'17'
			),
			(
			'cebolla',
			'10',
			'4'
			),
			(
			'pepino',
			'15',
			'8'
			),
			(
			'tomate',
			'33',
			'16'
			)

INSERT INTO TBL_Bodegas (
	bdg_descripcion
) VALUES (
			'Bodega1'
			),
			(
			'Bodega2'
			),
			(
			'Bodega3'
			),
			(
			'Bodega4'
			),
			(
			'Bodega5'
			),
			(
			'Bodega6'
			),
			(
			'Bodega7'
			),
			(
			'Bodega8'
			),
			(
			'Bodega9'
			),
			(
			'Bodega10'
			)


INSERT INTO TBL_Bodegas_Detalle (
	bdg_id ,
	prd_id ,
	bdg_cantidad_producto ,
	bdg_ubicacion_producto
)
VALUES (
		1,
		1,
		2,
		'0101'
		),
		(
		1,
		2,
		15,
		'0102'
		),
		(
		1,
		5,
		3,
		'0015'
		),
		(
		1,
		8,
		30,
		'0002'
		),
		(
		1,
		10,
		15,
		'0100'
		),
		(
		1,
		11,
		45,
		'0108'
		),
		(
		1,
		13,
		20,
		'0300'
		),
		(
		1,
		18,
		10,
		'0302'
		),
		(
		1,
		20,
		30,
		'0303'
		),
		(
		1,
		22,
		100,
		'0400'
		)
